የእህል ወፍጮ መተግበሪያ — እንዴት እንደሚከፈት
1. ዚፉን ፋይል ይንቀሉ (Extract)።
2. AndroidIDE ውስጥ "Open Project" ይምረጡና GrainMill ፎልደሩን ይክፈቱ።
3. Build / Run ይጫኑ። APK ተፈጥሮ ስልክዎ ላይ ይጫናል።
