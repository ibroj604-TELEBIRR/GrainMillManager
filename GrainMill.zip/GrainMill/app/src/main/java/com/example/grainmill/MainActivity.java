package com.example.grainmill;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {

    private SQLiteDatabase db;
    private Spinner grainSpinner, expenseSpinner;
    private EditText qtyInput, feeInput, expenseInput;
    private TextView summaryText;

    private static final String[] GRAINS = {"ጤፍ", "በቆሎ", "ሩዝ", "ስንዴ", "ገብስ", "ሌላ"};
    private static final String[] EXPENSES = {"ኤሌክትሪክ", "ጉልበት ሰራተኛ", "ጥገና", "ዘይት", "ሌሎች"};
    private static final int NUM = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        db = openOrCreateDatabase("grainmill.db", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS milling (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, grain TEXT, qty REAL, fee REAL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, category TEXT, amount REAL)");

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 32);
        root.setBackgroundColor(Color.parseColor("#F5F1E8"));
        scroll.addView(root);
        setContentView(scroll);

        addTitle(root, "የእህል ወፍጮ ሂሳብ");

        addTitle(root, "ገቢ (የመፍጨት ክፍያ)");
        grainSpinner = spinner(root, GRAINS);
        qtyInput = input(root, "የተፈጨው መጠን (ኪሎ)", NUM);
        feeInput = input(root, "ክፍያ (ብር)", NUM);
        button(root, "ገቢ ጨምር", v -> addIncome());

        addTitle(root, "ወጪ");
        expenseSpinner = spinner(root, EXPENSES);
        expenseInput = input(root, "መጠን (ብር)", NUM);
        button(root, "ወጪ ጨምር", v -> addExpense());

        addTitle(root, "ማጠቃለያ");
        summaryText = new TextView(this);
        summaryText.setTextSize(16);
        summaryText.setTextColor(Color.BLACK);
        root.addView(summaryText);
        button(root, "አድስ", v -> refresh());

        refresh();
    }

    private void addTitle(LinearLayout root, String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(20);
        t.setTextColor(Color.parseColor("#5A3E1B"));
        t.setPadding(0, 32, 0, 12);
        root.addView(t);
    }

    private Spinner spinner(LinearLayout root, String[] items) {
        Spinner s = new Spinner(this);
        s.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        root.addView(s);
        return s;
    }

    private EditText input(LinearLayout root, String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(type);
        root.addView(e);
        return e;
    }

    private void button(LinearLayout root, String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        root.addView(b);
    }

    private String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private double num(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim()); }
        catch (Exception ex) { return 0; }
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    private void addIncome() {
        double qty = num(qtyInput), fee = num(feeInput);
        if (qty <= 0 || fee <= 0) { toast("መጠንና ክፍያ ያስገቡ"); return; }
        db.execSQL("INSERT INTO milling (date, grain, qty, fee) VALUES (?,?,?,?)",
                new Object[]{today(), GRAINS[grainSpinner.getSelectedItemPosition()], qty, fee});
        qtyInput.setText("");
        feeInput.setText("");
        toast("ተመዝግቧል");
        refresh();
    }

    private void addExpense() {
        double amt = num(expenseInput);
        if (amt <= 0) { toast("መጠን ያስገቡ"); return; }
        db.execSQL("INSERT INTO expenses (date, category, amount) VALUES (?,?,?)",
                new Object[]{today(), EXPENSES[expenseSpinner.getSelectedItemPosition()], amt});
        expenseInput.setText("");
        toast("ተመዝግቧል");
        refresh();
    }

    private double sum(String table, String column, String where) {
        Cursor c = db.rawQuery("SELECT COALESCE(SUM(" + column + "),0) FROM " + table + " WHERE " + where, null);
        c.moveToFirst();
        double v = c.getDouble(0);
        c.close();
        return v;
    }

    private String fmt(double v) {
        return String.format(Locale.US, "%.2f", v);
    }

    private void refresh() {
        String[][] periods = {
            {"ዛሬ", "date = date('now','localtime')"},
            {"ይህ ሳምንት (7 ቀን)", "date >= date('now','localtime','-6 days')"},
            {"ይህ ወር", "strftime('%Y-%m', date) = strftime('%Y-%m','now','localtime')"}
        };

        StringBuilder sb = new StringBuilder();
        for (String[] p : periods) {
            double income = sum("milling", "fee", p[1]);
            double expense = sum("expenses", "amount", p[1]);
            sb.append("== ").append(p[0]).append(" ==\n")
              .append("ገቢ: ").append(fmt(income)).append(" ብር\n")
              .append("ወጪ: ").append(fmt(expense)).append(" ብር\n")
              .append("ትርፍ: ").append(fmt(income - expense)).append(" ብር\n\n");
        }

        sb.append("-- ዛሬ የተፈጨው --\n");
        Cursor c = db.rawQuery("SELECT grain, SUM(qty), SUM(fee) FROM milling " +
                "WHERE date = date('now','localtime') GROUP BY grain", null);
        while (c.moveToNext()) {
            sb.append(c.getString(0)).append(": ").append(fmt(c.getDouble(1)))
              .append(" ኪ.ግ — ").append(fmt(c.getDouble(2))).append(" ብር\n");
        }
        c.close();

        summaryText.setText(sb.toString());
    }
}
